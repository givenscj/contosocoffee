
<?php $__env->startSection('content'); ?>

	<h3>Choose a category</h3>

	<div class="center-block category-list">
		<div class="two-thirds column">
			<div class="row">
			<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="category one-third column" data-url="<?php echo e($c->url); ?>">
					<div class="image" style="background-image:url(/img/<?php echo e($c->img); ?>);"></div>
					<span><?php echo e($c->name); ?></span>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
		<button class="select-category button" disabled>Continue</button>
	</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\labfiles\microsoft-mysql-developer-guide\sample-php-app\resources\views/category-list.blade.php ENDPATH**/ ?>