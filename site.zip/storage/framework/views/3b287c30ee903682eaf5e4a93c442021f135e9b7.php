
<?php $__env->startSection('content'); ?>

	<h3>Checkout</h3>

	<div class="center-block item-list">
		<div class="two-thirds column">
			<?php if($cart_data): ?>
			<table class="u-full-width m-b-0 checkout-cart">
				<tbody>
				<?php $__currentLoopData = $cart_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><div class="image" style="background-image:url(/img/<?php echo e($c->img); ?>);"></div></td>
						<td>
							<span><?php echo e($c->name); ?></span>
							<span><?php echo e($c->qty); ?> @ <?php echo e(is_numeric($c->price) ? number_format($c->price, 2) : '0.00'); ?></span>
						</td>
						<td><?php echo e(number_format($c->sub, 2)); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td colspan="2">Total:</td>
						<td>$ <?php echo e(number_format($cart_total, 2)); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div class="one-half column">
			<form method="post" action="<?php echo e(route('process-order')); ?>">
				<?php echo e(csrf_field()); ?>


				<!-- keeping it simple for demo purposes, only displaying a few fields -->
				<label for="name" class="text-left">Name</label>
				<input id="name" name="name" type="text" class="u-full-width" value="<?php echo e($user ?? '' ? $user->name : ''); ?>">
				<label for="address" class="text-left">Address</label>
				<input id="address" name="address" type="text" class="u-full-width" value="<?php echo e($user ?? '' ? $user->address : ''); ?>">
				<label for="special_instruction" class="text-left">Special Instructions</label>
				<textarea id="special_instruction" name="special_instructions" class="u-full-width"></textarea>

				<a href="<?php echo e(route('category-list')); ?>" class="button">Add to Order</a>
				<button class="button button-primary complete-order">Complete Order</button>
			</form>
			<?php else: ?>
			<p>You have no food in your cart.</p>
			<a href="<?php echo e(route('category-list')); ?>" class="button">Start a New Order</a>
			<?php endif; ?>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\labfiles\microsoft-mysql-developer-guide\sample-php-app\resources\views/checkout.blade.php ENDPATH**/ ?>