
<?php $__env->startSection('content'); ?>

	<div class="hero">
		<div class="logo">Contoso NoshNow</div>
	</div>

	<div class="center-block order-form">
		<div class="one-half column">
			<form>
				<label for="delivery_address">Welcome back, <?php echo e($user->name); ?>! Where should we deliver your meal?</label>
				<!-- 
					Keeping it simple for demo purposes, only displaying a single street address field. We don't
					actually use this field for anything though. It's just for show!
				 -->
				<input id="delivery_address" class="u-full-width" type="text" placeholder="Enter your street address" value="<?php echo e($user->address); ?>">
				<a href="<?php echo e(route('category-list')); ?>" class="start-order button button-primary">Start Order</a>
			</form>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\labfiles\microsoft-mysql-developer-guide\sample-php-app\resources\views/index.blade.php ENDPATH**/ ?>