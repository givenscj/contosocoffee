
<?php $__env->startSection('content'); ?>

	<h3>Select a meal</h3>

	<div class="center-block item-list">
		<div class="two-thirds column">
			<div class="row">
			<?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="item one-third column">
					<div class="image" style="background-image:url(/img/<?php echo e($i->img); ?>);"></div>
					<div class="name"><?php echo e($i->name); ?></div>
					<div class="price"><sup>$</sup><?php echo e(is_numeric($i->price) ? number_format($i->price, 2) : '0.00'); ?></div>
					<div class="desc">
						<div class="overflow"><?php echo e($i->desc); ?></div>
					</div>
					<button class="add-to-cart button-small button-primary" data-item="<?php echo e($i->id); ?>">Add</button>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
		<a href="<?php echo e(route('category-list')); ?>" class="button">Back</a>
		<button class="button <?php echo e($global_cart['cart_total'] ? 'button-primary' : ''); ?> checkout-button" <?php echo e($global_cart['cart_total'] ? '' : 'disabled'); ?>>Continue</button>
	</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
// to keep the layout and design simple, only show 6 lines of text from the item description
var ellipsis_lines = 6;
$(document).ready( function() {
	ellipsis();

	$('.checkout-button').on('click', function() {
		var url = "<?php echo e(route('checkout')); ?>";
		// fun little trick to allow ctrl-click on a javascript click event just like regular links
		if (event.metaKey || event.ctrlKey) {
			window.open(url,'_blank');
		} else {
			location.href = url;
		}
	});

});
$(window).resize( function() {
	ellipsis();
});

// function to add ellipsis after (N) lines of text
function ellipsis() {
	var lines = ellipsis_lines;
	$('.overflow').each(function( index ) {
		var inner = $(this);
		var outer = inner.parent();
		if (inner.attr('data-text')) {
			var innertext = inner.attr('data-text');
		} else {
			var innertext = inner.text();
		}
		var lineheight = inner.css('line-height');
		var height = (lineheight.replace('px','')-0)*(lines-0);
		outer.css({'height':height});
		inner.attr('data-text',innertext);
		inner.text(innertext);
		while (inner.outerHeight() > height) {
			inner.text(function (index, text) {
				return text.replace(/\W*\s(\S)*$/, '...');
			});
		}
	});
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\labfiles\microsoft-mysql-developer-guide\sample-php-app\resources\views/item-list.blade.php ENDPATH**/ ?>