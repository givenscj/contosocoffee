
<?php $__env->startSection('content'); ?>

	<h3>Receipt</h3>

	<div class="center-block item-list">
	<p>Thank you for placing your food order with <?php echo e(config('app.name', '')); ?>!</p>
	<p id="remaining_text"></p>

	<a href="<?php echo e(route('category-list')); ?>" class="button">Start a New Order</a>
	</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready( function() {
	set_receipt_text('<?php echo e($time_left ?? '0'); ?>');
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\labfiles\microsoft-mysql-developer-guide\sample-php-app\resources\views/receipt.blade.php ENDPATH**/ ?>